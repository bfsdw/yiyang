# Transaction Management API

## 功能特性
- 创建/删除/修改/查询交易
- 内存存储（无需数据库）
- 缓存支持（Caffeine）
- 分页查询
- 统一异常处理

## 快速启动
```bash
mvn spring-boot:run