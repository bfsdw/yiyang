package com.example.transaction.model;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Transaction {
    private String id;
    private BigDecimal amount;
    private String type; // INCOME/EXPENSE
    private String description;
    private LocalDateTime timestamp;
}